
import React, { useState } from "react";
import Fridge from "./components/Fridge";
import RecipeSuggestions from "./components/RecipeSuggestions";
import AddIngredientForm from "./components/AddIngredientForm";

function App() {
  const [ingredients, setIngredients] = useState([]);

  const addIngredient = (ingredient) => {
    setIngredients([...ingredients, ingredient]);
  };

  const removeIngredient = (index) => {
    setIngredients(ingredients.filter((_, i) => i !== index));
  };

  return (
    <div>
      <h1>Frigo Chef</h1>
      <AddIngredientForm addIngredient={addIngredient} />
      <Fridge ingredients={ingredients} removeIngredient={removeIngredient} />
      <RecipeSuggestions ingredients={ingredients} />
    </div>
  );
}

export default App;
